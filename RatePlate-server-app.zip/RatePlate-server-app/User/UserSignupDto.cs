using System.ComponentModel.DataAnnotations;

namespace RatePlate.Dto
{
    public class UserSignupDto
    {
        public string Username { get; set; }
        public string Email {get; set; }
        
    }
}